# bot-indomaret-point
BOT OK
